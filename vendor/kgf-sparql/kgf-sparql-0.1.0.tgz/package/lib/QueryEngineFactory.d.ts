import { QueryEngineFactoryBase } from '@comunica/actor-init-query';
import { QueryEngine } from './QueryEngine';
/** Builds a KGF query engine from an arbitrary Components.js config path. */
export declare class QueryEngineFactory extends QueryEngineFactoryBase<QueryEngine> {
    constructor();
}
//# sourceMappingURL=QueryEngineFactory.d.ts.map